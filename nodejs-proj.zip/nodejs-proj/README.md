Instructions on how to run the assignment:

Instrucions to run the server:
    - From VSCode: 
        - Click run from the top menu bar, then select start debugging, then select node.js. You can also run this command from the terminal, but please ensure you are following the right directory. Everything starts from the server file. Note that I have specified a port to be used (at the bottom of the server.js for q4, for all other qs it is specified in the file. If the page isn't appearing as found, try to rerun the code, and/or change the port to a port that is available.)


        Go to the terminal, either on VS Code or just the general terminal:

        For q4 - use node server.js 
        Note for this question the link is available at: http://soen287.encs.concordia.ca:5366/
        IF YOU CHANGE THE PORT, PLEASE CHANGE IT ON THE LINK TOO. 



        For q1 - use node server1.js !PLEASE ENSURE YOU ARE IN THE CORRECT DIRECTORY, this is located inside node-js-proj and then even deeper into it we have questions, and then the servers. 
        http://soen287.encs.concordia.ca:5365/

        IF YOU CHANGE THE PORT, PLEASE CHANGE IT ON THE LINK TOO.

        Follow the same procedure for the other questions:
        
        For q3 - we have server3. For q2 we have numofvisits. 



Instructions on how to login:
    - A username can contain letters (both upper and lower case) and digits only.
    - A password must be at least 4 characters long (characters are to be letters 
      and digits only), have at least one letter 
      and at least one digit. 

Instructions on how to create an account:
    - A username can contain letters (both upper and lower case) and digits only.
    - A password must be at least 4 characters long (characters are to be letters 
      and digits only), have at least one letter 
      and at least one digit. 

    Please note that Usernames are case-sensitive.  

Instructions for entering information into "Give Pet Away / Have a Pet to Give Away ":
    - Follow the form as usual. Try not to enter conflicting information such as a cat with the breed as a husky. I know I have only one cat breed, so try to use "doesn't matter" for entering cats.
    - When entering the breedname, please use only lowercases and hyphens instead of spaces.

Instructions for entering information into the pets.txt file:
    - Ideally, a user would have no access to this file so no need to know how to write to it.
    - If you must write to it, follow this format:
    - #:username:pettype:breed:age:gender:otherdogs:othercats:otherchildren:comment:ownername:owneremail
    - look at the pets.txt file if you are having difficulties entering new entires maually in pets.txt
    - if you want to see all the options, please check the form html code in givepetaway.ejs
       


>>>>>>>NOTE: If you are getting errors in the debug console, it is most likey becuause the relative path of the files aren't working. <<<<<<<

>>>>>>>NOTE2: Pets listed under "Browse Availiable Pets" are not ACTUALLY AVAIABLE in the pets.txt file!<<<<<<<

>>>>>>>NOTE3: If pets are being added on the same line, please move your cursor to the end of the last entry in the 
pets.txt file (ideally you shouldnt click anywhere in there!!)<<<<<<<