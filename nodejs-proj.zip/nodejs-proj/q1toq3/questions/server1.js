// Assignment 3 - SOEN 287 - Yuhong Yan - Summer II 2024
// Submitted By: Afra Azreen (Student ID: 40234047)
// Submitted On: 10/08/24
// Question 1 - Server 


const express = require('express');
const bodyParser = require('body-parser');
const app = express();
const port = 5365;

app.use(bodyParser.urlencoded({ extended: true }));

// Route for the main form page
app.get('/', (req, res) => {
    res.sendFile(__dirname + '/q1.html');
});

// Function: findSummation
app.post('/findSummation', (req, res) => {
    const number = parseInt(req.body.number);
    const result = findSummation(number);
    res.send(`Summation result: ${result}`);
});

function findSummation(n) {
    if (typeof n !== 'number' || n <= 0 || isNaN(n)) {
        return false;
    }
    return (n * (n + 1)) / 2;
}

// Function: uppercaseFirstandLast
app.post('/uppercaseFirstandLast', (req, res) => {
    const text = req.body.text;
    const result = uppercaseFirstandLast(text);
    res.send(`Modified string: ${result}`);
});

function uppercaseFirstandLast(str) {
    if (typeof str !== 'string' || str.trim().length === 0) {
        return false;
    }
    return str.split(' ').map(word => {
        if (word.length === 1) {
            return word.toUpperCase();
        }
        return word.charAt(0).toUpperCase() + word.slice(1, -1) + word.charAt(word.length - 1).toUpperCase();
    }).join(' ');
}

// Function: findAverageAndMedian
app.post('/findAverageAndMedian', (req, res) => {
    const numbers = req.body.numbers.split(',').map(Number);
    const { average, median } = findAverageAndMedian(numbers);
    res.send(`Average: ${average}, Median: ${median}`);
});

function findAverageAndMedian(arr) {
    if (!Array.isArray(arr) || arr.length === 0 || arr.some(isNaN)) {
        return false;
    }
    const sortedArr = arr.slice().sort((a, b) => a - b);
    const sum = arr.reduce((acc, num) => acc + num, 0);
    const average = sum / arr.length;
    let median;
    if (sortedArr.length % 2 === 0) {
        median = (sortedArr[sortedArr.length / 2 - 1] + sortedArr[sortedArr.length / 2]) / 2;
    } else {
        median = sortedArr[Math.floor(sortedArr.length / 2)];
    }
    return { average, median };
}

// Function: find4Digits
app.post('/find4Digits', (req, res) => {
    const numberString = req.body.numberString;
    const result = find4Digits(numberString);
    res.send(`First 4-digit number: ${result}`);
});

function find4Digits(input) {
    const finddigits = input.replace(/\D/g, ' ').slice(0, 4);
    if (finddigits.length < 4)
        return false;

    return Number(finddigits);
}


app.listen(port, () => {
    console.log(`Server is running on http://soen287.encs.concordia.ca:${port}`);
});
