// Assignment 3 - SOEN 287 - Yuhong Yan - Summer II 2024
// Submitted By: Afra Azreen (Student ID: 40234047)
// Submitted On: 10/08/24
// Question 2 - Server 

const express = require('express');
const cookieParser = require('cookie-parser');
const app = express();
const port = 5367;

app.use(cookieParser());

app.get('/', (req, res) => {
  let visitCount = req.cookies.visitCount;
  let lastVisit = req.cookies.lastVisit;
  let message;

  if (!visitCount) {
    // First visit
    visitCount = 1;
    message = "Welcome to my webpage! It is your first time that you are here.";
  } else {
    // For all following visits
    visitCount = parseInt(visitCount) + 1;
    message = `Hello, this is the ${visitCount} time that you are visiting my webpage.`;
    if (lastVisit) {
      message += `<br>Last time you visited my webpage on: ${lastVisit}`;
    }
  }

  // Updating the cookies
  const currentDate = new Date().toString();
  res.cookie('visitCount', visitCount, { maxAge: 900000, httpOnly: true });
  res.cookie('lastVisit', currentDate, { maxAge: 900000, httpOnly: true });

  res.send(message);
});

app.listen(port, () => {
  console.log(`Server is running on http://soen287.encs.concordia.ca: ${port}`);
});
