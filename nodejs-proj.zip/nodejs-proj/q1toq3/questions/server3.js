// Assignment 3 - SOEN 287 - Yuhong Yan - Summer II 2024
// Submitted By: Afra Azreen (Student ID: 40234047)
// Submitted On: 10/08/24
// Question 3 - Server 

// Importing necessary modules
const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');

// Creating an instance of Express application
const app = express();

// Defining the port number to listen on
const port = 5368;

// Middleware to parse URL-encoded data from the form
app.use(bodyParser.urlencoded({ extended: true }));

// Route to serve the HTML form when the root URL is accessed
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname + '/q3.html'));
});

// Route to handle form submission
app.post('/submit', (req, res) => {
  // Destructuring the name and phone from the request body
  const { name, phone } = req.body;

  // Regular expression to validate phone number format ddd-ddd-dddd
  const phoneRegex = /^\d{3}-\d{3}-\d{4}$/;

  // Checking if the phone number matches the required format
  if (phoneRegex.test(phone)) {
    // If the phone number is valid, send a success message
    res.send(`Hello ${name}, your phone number ${phone} is valid.`);
  } else {
    // If the phone number is invalid, send an error message
    res.send(`Hello ${name}, your phone number ${phone} is invalid. Please enter a number in the format ddd-ddd-dddd.`);
  }
});

// Start the server and listen on the specified port
app.listen(port, () => {
  console.log(`Server is running on http://soen287.encs.concordia.ca:${port}`);
});
