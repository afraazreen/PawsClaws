// Assignment 3 - SOEN 287 - Yuhong Yan - Summer II 2024
// Submitted By: Afra Azreen (Student ID: 40234047)
// Submitted On: 10/08/24
// Question 4 - Server

const express = require('express');
const session = require('express-session');
const bodyParser = require('body-parser');
const path = require('path');
const fs = require('fs');
const readline = require('readline');
const { name } = require('ejs');


const app = express();

//Set the views directory
app.set('views', path.join(__dirname, 'views'));

//Set the public directory
app.use(express.static(path.join(__dirname,'public')));

app.use(express.urlencoded({ extended: true}))

app.use(bodyParser.urlencoded({ extended: true}));

//Express sessions
app.use(session({
    secret: 'random',
    resave: false,
    saveUninitialized: false
}));


function checkAuth(req, res, next) {
    if (req.session.isAuthenticated) {
        res.locals.isAuthenticated = true;
        res.locals.username = req.session.username;
    } else {
        res.locals.isAuthenticated = false;
    }
    next();
}

//COPY RELATIVE PATHS FOR EACH TIME USERS.TXT OR PETS.TXT IS ACALLED
//Function to check if a username is already taken
function isUsernameTaken(username) {
    const fileContent = fs.readFileSync('users.txt', 'utf8');
    const usernames = fileContent.split('\n').map(line => line.split(':')[0]);
    return usernames.includes(username);
}

//Function to check if a username-password combo already exists
function isCredentialExists(username, password) {
    try {
        //Read the content of the text file
        const fileContent = fs.readFileSync('users.txt', 'utf8');

        //Split the content into lines
        const lines = fileContent.trim().split('\n');

        //Check each line for the provided username-password combination
        for (const line of lines) {
            const [storedUsername, storedPassword] = line.split(':');
            if (storedUsername === username && storedPassword === password) {
                return true; // Username-password combination found
            }
        }

        return false; // Username-password combination not found
    } catch (error) {
        console.error('Error reading users file:', error);
        return false;
    }
}

//Function to add pet info to pets.txt file
function addPetInfo(username, animalType,breed,age,gender,otherDogs,otherCats,smallChildren,comment,ownerName,ownerEmail) {
    try {
        //Read the current content of the pet information file
        let fileContent = fs.readFileSync('pets.txt', 'utf8');

        //Initialize ID counter
        let lastId = 0;

        //If the file is not empty, get the last ID from the file
        if (fileContent.trim() !== '') {
            const lines = fileContent.trim().split('\n');
            const lastLine = lines[lines.length - 1];
            lastId = parseInt(lastLine.split(':')[0]);
        }

        //Increment the ID for the new entry
        const newId = isNaN(lastId) ? 1 : lastId + 1;

        //Construct the new entry with the ID, username, and pet info
        const newEntry = `${newId}:${username}:${animalType}:${breed}:${age}:${gender}:${otherDogs}:${otherCats}:${smallChildren}:${comment}:${ownerName}:${ownerEmail}`;

        //Append the new entry to the file
        fs.appendFileSync('pets.txt', `${newEntry}\n`);

        console.log('Pet information added successfully.');
    } catch (error) {
        console.error('Error adding pet information:', error);
    }
}

//Function to filter pet records based on form criteria
function filterPetRecords(petRecords, formCriteria) {
    return petRecords.filter(record => {
        const [id, username, animalType, petBreed, petAge, petGender, getsAlongDogs, getsAlongCats, getsAlongChildren] = record.split(':');
        return (
            (formCriteria.animaltype === '' || animalType === formCriteria.animaltype) &&
            (formCriteria.breed === "doesn't matter" || petBreed === formCriteria.breed || formCriteria.breed === '') &&
            (formCriteria.age === "doesn't matter" || petAge === formCriteria.age || formCriteria.age === '') &&
            (formCriteria.gender === "doesn't matter" || petGender === formCriteria.gender || formCriteria.gender === '') &&
            (formCriteria.otherdogs === 'on' ? getsAlongDogs === 'Yes' : true) &&
            (formCriteria.othercats === 'on' ? getsAlongCats === 'Yes' : true) &&
            (formCriteria.otherchildren === 'on' ? getsAlongChildren === 'Yes' : true)
        );
    });
}

app.use(checkAuth);

//Set EJS as the view engine
app.set('view engine', 'ejs');

//Define routes
//1. Home.ejs 
app.get('/', (req, res) => {
    res.render('homeStyleLayout', {
        pageTitle: 'Home',
        content: 'home',
    });
});

//2. createaccount.ejs
app.get('/createaccount', (req, res) => {
    res.render('homeStyleLayout', {
        pageTitle: 'Account Creation',
        content: 'createaccount',
    });
});

//3. catCare.ejs 
app.get('/catCare', (req, res) => {
    res.render('animalStyleLayout', {
        pageTitle: 'Cat Care',
        content: 'catCare',
    });
});

//4. dog.ejs 
app.get('/dog', (req, res) => {
    res.render('animalStyleLayout', {
        pageTitle: 'Dog Care',
        content: 'dog',
    });
});

//5. givepetaway.ejs
app.get('/givepetaway', (req, res) => {
    if(req.session.isAuthenticated){
    res.render('giveLayout', {
        pageTitle: 'Have A Pet To Giveaway',
        content: 'givepetaway' 
    });
    }
    else{
        res.render('giveLayout', {
            pageTitle: 'Access Denied',
            content: 'accessDenied',
        });
    }
});

//6. browseandfindpets.ejs
app.get('/browseandfindpets', (req, res) => {
    res.render('browseStyleLayout', {
        pageTitle: 'Find A Pet',
        content: 'browseandfindpets',
    });
});

//7. contact.ejs
app.get('/contactus', (req, res) => {
    res.render('homeStyleLayout', {
        pageTitle: 'Contact Us',
        content: 'contactus',
    });
});

//8. successAccount.ejs
app.get('/successAccount', (req,res) => {
    res.render('homeStyleLayout', {
        pageTitle: 'Account Created',
        content: 'successAccount',
    });
});

//9. login 
app.get('/login', (req,res) => {
    res.redirect('login-page');
});

//10. loginpage.ejs
app.get('/loginpage', (req,res) => {
    res.render('homeStyleLayout', {
        pageTitle: 'Log in',
        content: 'loginpage',
    });
});

//11. logout
app.get('/logout', (req, res) => {
    req.session.destroy(() => {
        res.redirect('/logoutpage')
    });
});

//12. logout-page
app.get('/logoutpage', (req,res) => {
    res.render('homeStyleLayout', {
        pageTitle: 'Logged out',
        content: 'logoutpage',
    });
});
//13. loggedIn.ejs
app.get('/logSuccess', (req,res) => {
    res.render('homeStyleLayout', {
        pageTitle: 'Logged in',
        content: 'logSuccess',
    });
});

//13. userTaken.ejs
app.get('/userTaken', (req,res) => {
    res.render('homeStyleLayout', {
        pageTitle: 'Username Taken',
        content: 'userTaken',
    });
});

//14. userDoesNotExist.ejs
app.get('/userDoesNotExist', (req,res) => {
    res.render('homeStyleLayout', {
        pageTitle: 'Username Does Not Exist',
        content: 'userDoesNotExist',
    });
});

//15. addedPet.ejs
app.get('/addedPet', (req,res) => {
    res.render('giveLayout', {
        pageTitle: 'Added A Pet',
        content: 'addedPet',
    });
});

//16. filteredPet.ejs
app.get('/filteredPets', (req,res) => {
    res.render('giveLayout', {
        pageTitle: 'Filtered Pets',
        content: 'filteredPets',
    });
});

//17. privacy.ejs
app.get('/privacy', (req,res) => {
    res.render('homeStyleLayout', {
        pageTitle: 'Privacy Disclaimer',
        content: 'privacy',
    });
});

//Forms
//Define routes
app.post('/submitLogin', (req,res) =>{     
    console.log(req.body)
    const usernameToCheck = req.body.username;
    const passwordToCheck = req.body.password;
   
    //Check if username and password combo exists
    if (isCredentialExists(usernameToCheck, passwordToCheck)) {
        req.session.isAuthenticated = true;         //Login the user automatically
        req.session.username = req.body.username;   //Set username in session
        res.redirect('/logSuccess');
    }
    else{
        res.redirect('/userDoesNotExist');
    }
});

app.post('/submitgiveaway', (req,res) =>{       //giveaway pet
    const username = req.session.username;
    const animalType = req.body.animaltype;
    const breed = req.body.breed;
    const age = req.body.age;
    const gender = req.body.gender;
    const otherDogs = req.body.getsalongdogs === 'on' ? 'Yes' : 'No'; // Checkbox value handling
    const otherCats = req.body.getsalongcats === 'on' ? 'Yes' : 'No'; // Checkbox value handling
    const smallChildren = req.body.suitablechildren === 'on' ? 'Yes' : 'No'; // Checkbox value handling
    const comment = req.body.comments;
    const ownerName = req.body.ownername;
    const ownerEmail = req.body.owneremail;
    
    addPetInfo(username,animalType,breed,age,gender,otherDogs,otherCats,smallChildren,comment,ownerName,ownerEmail)

    res.redirect('/addedPet')
});

app.post('/submitFind', (req, res) => {         //Find pet
    try {
        //Read the pet information file
        const fileContent = fs.readFileSync('pets.txt', 'utf8');

        //Split the file content into pet records
        const petRecords = fileContent.trim().split('\n');

        //Extract form data
        const formCriteria = req.body;

        //Filter pet records based on form criteria
        const filteredPetRecords = filterPetRecords(petRecords, formCriteria);

        //Render filteredPets.ejs with filtered pet records
        res.render('filteredPets', { filteredPetRecords });
    } catch (error) {
        console.error('Error processing form submission:', error);
        res.status(500).send('Internal Server Error');
    }
});

app.post('/submitCreateAccount', (req,res) =>{       //Creates an account
    console.log(req.body)
    const usernameToCheck = req.body.username;
   
    //Check if username is taken or already logged in
    if (isUsernameTaken(usernameToCheck)) {
        res.redirect('/userTaken');
    }
    else{

    //Write username and password to user.txt
    fs.appendFileSync('users.txt', `${req.body.username}:${req.body.password}\n`);

    req.session.isAuthenticated = true;         //Login the user automatically
    req.session.username = req.body.username;   //Set username in session
    
    //Return success response
    res.redirect('/successAccount');
    }

});


//Start the server
const PORT = 3000;
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`); 
});